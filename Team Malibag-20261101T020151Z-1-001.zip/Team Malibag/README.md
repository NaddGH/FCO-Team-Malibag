# Offline Learning Companion (OLC)

A study companion that works with **no internet connection**. It combines three
small, explainable components, all implemented with NumPy only:

| Component | What it does | Module |
|---|---|---|
| Forgetting-curve estimator | Estimates how fast a learner forgets a concept, `p(t) = exp(-t/S)`, by maximum likelihood using **gradient descent** and **Newton's method** | `olc/forgetting.py` |
| Review scheduler | Tells the learner when to review: `t* = -S ln(r*)` for a target recall `r*` | `olc/scheduler.py` |
| Offline note search | Answers a question by retrieving the best local study note with **TF-IDF + cosine similarity** | `olc/retrieval.py` |

> **Data note.** No real student data is used. The memory-decay experiments use a
> seeded synthetic learner (`olc/simulate.py`); the retrieval experiment uses the
> 20 short study notes and 40 queries in `data/notes.json`, written by the authors.

## Requirements
Python 3.9+ and the packages in `requirements.txt` (NumPy, Matplotlib).

## Setup and run
```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python experiments/run_all.py      # regenerates every figure/table in results/ (about 10 s)
python -m unittest discover -s tests -v   # 14 unit tests
```
Everything is seeded (`SEED = 2026`), so all statistical results are identical on every run. Only the
machine-dependent timing values (`*_ms_per_fit` in `exp2_tolerance.csv` and `latency` in `summary.json`) change.

### Try the companion (command line prototype)
```bash
python -m olc.cli ask "slope of the tangent line"
python -m olc.cli plan --today 7 --target 0.85
```

## Repository layout
```
olc/            forgetting.py  scheduler.py  retrieval.py  simulate.py  cli.py
experiments/    run_all.py          -> writes results/
data/           notes.json (notes + labelled queries), sample_state.json
results/        fig1..fig4 (.png), exp1..exp5 (.csv), summary.json
tests/          test_olc.py
docs/           video_script.md
```

## Output files
`results/fig1_convergence.png`, `fig2_estimation_error.png`, `fig3_scheduling_tradeoff.png`,
`fig4_retrieval.png`, `exp2_tolerance.csv`, `exp3_estimation_error.csv`,
`exp4_scheduling.csv`, `exp5_retrieval.csv`, `summary.json`.

## Method settings (see paper, Section 3)
* Gradient descent: fixed step size (default 0.5; experiments use 1.0), start `theta0 = ln 0.3`, stop when `|gradient| < tol` (default `1e-6`), at most 5000 iterations.
* Newton: same start and tolerance, at most 200 iterations, step halving (up to 40 times) so the objective never increases.
* Memory strength is bounded to `S in [0.01, 1000]` days; fits that hit the bound are flagged (`hit_bound`).

## Limitations
Synthetic learner that follows the same model the scheduler assumes (optimistic); small
hand-written retrieval benchmark; no deployment with real students yet.

## Team workflow (version history)
Each member should commit **their own** work from their own account so the history shows
real collaboration:
```bash
git init && git add . && git commit -m "Initial import"
git remote add origin <your-repo-url> && git push -u origin main
# each member: git checkout -b feature/<name>; commit; push; open a pull request
```
