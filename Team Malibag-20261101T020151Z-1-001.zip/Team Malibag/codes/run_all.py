"""Reproduce every number and figure in the paper.  Usage:  python experiments/run_all.py
All randomness is seeded (SEED) so results are identical on every run."""
from __future__ import annotations

import csv
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from olc.forgetting import fit_gradient_descent, fit_newton, objective
from olc.retrieval import TfidfIndex, overlap_scores
from olc.simulate import calibration_reviews, draw_true_strengths, run_policy

SEED = 2026
RES = ROOT / "results"
RES.mkdir(exist_ok=True)
plt.rcParams.update({"figure.dpi": 150, "axes.grid": True, "grid.alpha": 0.3, "font.size": 10})
summary: dict = {"seed": SEED}


def write_csv(name, header, rows):
    with open(RES / name, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)


# ---------------------------------------------------------------- Exp 1
def exp1_convergence():
    rng = np.random.default_rng(SEED)
    t, y = calibration_reviews(5.0, 60, rng)
    ref = fit_newton(t, y, tol=1e-12)
    f_star = objective(ref.theta, t, y)
    summary["exp1"] = {"n": 60, "true_S": 5.0, "newton_S": ref.strength, "newton_iters": ref.iterations}
    fig, ax = plt.subplots(figsize=(6.2, 4))
    rows = []
    for step in (0.1, 0.5, 1.0, 2.0, 4.0):
        r = fit_gradient_descent(t, y, step=step, tol=0.0, max_iter=60)
        gap = np.maximum(np.array(r.objective_history) - f_star, 1e-16)
        ax.semilogy(gap, label=f"GD step {step:g}")
        rows += [(f"gd_{step:g}", k, g) for k, g in enumerate(gap)]
    gap = np.maximum(np.array(ref.objective_history) - f_star, 1e-16)
    ax.semilogy(gap, "k-o", lw=2, ms=4, label="Newton")
    rows += [("newton", k, g) for k, g in enumerate(gap)]
    ax.set_xlabel("iteration")
    ax.set_ylabel("objective gap  f(θ_k) − f*")
    ax.set_title("Convergence of the forgetting-curve fit")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(RES / "fig1_convergence.png")
    plt.close(fig)
    write_csv("exp1_convergence.csv", ["method", "iteration", "gap"], rows)


# ---------------------------------------------------------------- Exp 2
def exp2_tolerance(n_datasets=200, n=60, gd_step=1.0):
    rng = np.random.default_rng(SEED + 1)
    data = []
    for s in draw_true_strengths(n_datasets, rng):
        data.append(calibration_reviews(s, n, rng))
    rows, out = [], {}
    for tol in (1e-2, 1e-4, 1e-6, 1e-8):
        rec = {}
        for name, fit in (("gd", lambda t, y: fit_gradient_descent(t, y, step=gd_step, tol=tol, max_iter=5000)),
                          ("newton", lambda t, y: fit_newton(t, y, tol=tol))):
            t0 = time.perf_counter()
            res = [fit(t, y) for t, y in data]
            ms = (time.perf_counter() - t0) / len(data) * 1e3
            ok = [r for r in res if r.converged]
            rec[name] = (float(np.mean([r.iterations for r in ok])) if ok else float("nan"),
                         100.0 * len(ok) / len(res), ms)
        rows.append((f"{tol:g}", f"{rec['gd'][0]:.1f}", f"{rec['gd'][1]:.1f}", f"{rec['gd'][2]:.3f}",
                     f"{rec['newton'][0]:.1f}", f"{rec['newton'][1]:.1f}", f"{rec['newton'][2]:.3f}"))
        out[f"{tol:g}"] = {"gd": rec["gd"], "newton": rec["newton"]}
    write_csv("exp2_tolerance.csv",
              ["tol", "gd_mean_iters", "gd_converged_pct", "gd_ms_per_fit",
               "newton_mean_iters", "newton_converged_pct", "newton_ms_per_fit"], rows)
    summary["exp2"] = {"datasets": n_datasets, "n": n, "gd_step": gd_step, "table": out}


# ---------------------------------------------------------------- Exp 3
def exp3_estimation_error(reps=20, n_concepts=30):
    rng = np.random.default_rng(SEED + 2)
    ns = [5, 10, 20, 40, 80, 160]
    rows, med, q25, q75, bound = [], [], [], [], []
    for n in ns:
        errs, hits = [], 0
        for _ in range(reps):
            for s in draw_true_strengths(n_concepts, rng):
                t, y = calibration_reviews(s, n, rng)
                r = fit_newton(t, y)
                errs.append(abs(np.log(r.strength / s)))
                hits += r.hit_bound
        errs = np.array(errs)
        med.append(np.median(errs)); q25.append(np.percentile(errs, 25)); q75.append(np.percentile(errs, 75))
        bound.append(100.0 * hits / len(errs))
        rows.append((n, f"{med[-1]:.4f}", f"{q25[-1]:.4f}", f"{q75[-1]:.4f}", f"{bound[-1]:.2f}"))
    write_csv("exp3_estimation_error.csv", ["n_reviews", "median_abs_log_error", "q25", "q75", "pct_hit_bound"], rows)
    summary["exp3"] = {"n": ns, "median": med, "q25": q25, "q75": q75, "pct_bound": bound,
                       "fits_per_n": reps * n_concepts}
    fig, ax = plt.subplots(figsize=(6.2, 4))
    ax.plot(ns, med, "o-", label="median")
    ax.fill_between(ns, q25, q75, alpha=0.25, label="interquartile range")
    ax.set_xscale("log", base=2)
    ax.set_xlabel("number of review observations per concept (n)")
    ax.set_ylabel("|ln(Ŝ / S)|  (0 = perfect)")
    ax.set_title("Accuracy of the estimated memory strength")
    ax.legend()
    fig.tight_layout()
    fig.savefig(RES / "fig2_estimation_error.png")
    plt.close(fig)


# ---------------------------------------------------------------- Exp 4
def exp4_scheduling(n_concepts=30, runs=50, calib_n=20, horizon=90.0):
    rng = np.random.default_rng(SEED + 3)
    s_true = draw_true_strengths(n_concepts, rng)
    s_hat = np.array([fit_newton(*calibration_reviews(s, calib_n, rng)).strength for s in s_true])

    def evaluate(**kw):
        revs, rets = [], []
        for _ in range(runs):
            for i in range(n_concepts):
                a = {k: (v[i] if isinstance(v, np.ndarray) else v) for k, v in kw.items()}
                r, _, ret = run_policy(s_true[i], rng, horizon=horizon, **a)
                revs.append(r); rets.append(ret)
        return float(np.mean(revs)), float(np.mean(rets))

    results = {}
    for d in (1.0, 2.0, 3.0, 5.0, 7.0, 14.0):
        results[f"fixed {d:g} d"] = evaluate(fixed_interval=d)
    targets = (0.6, 0.7, 0.8, 0.85, 0.9, 0.95)
    for tg in targets:
        results[f"adaptive (fitted) target {tg}"] = evaluate(s_est0=s_hat, target=tg)
        results[f"adaptive (oracle) target {tg}"] = evaluate(s_est0=s_true, target=tg)
    write_csv("exp4_scheduling.csv", ["policy", "reviews_per_concept", "retention_at_day_90"],
              [(k, f"{v[0]:.2f}", f"{v[1]:.4f}") for k, v in results.items()])
    summary["exp4"] = {"concepts": n_concepts, "runs": runs, "calib_n": calib_n, "horizon": horizon,
                       "results": results}
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    for lab, mk in (("fitted", "o-"), ("oracle", "s--")):
        pts = [results[f"adaptive ({lab}) target {tg}"] for tg in targets]
        ax.plot([p[0] for p in pts], [p[1] for p in pts], mk, label=f"adaptive ({lab} S)")
        if lab == "fitted":
            for tg, p in zip(targets, pts):
                ax.annotate(f"{tg:g}", p, textcoords="offset points", xytext=(4, -10), fontsize=7)
    for d in (1.0, 2.0, 3.0, 5.0, 7.0, 14.0):
        p = results[f"fixed {d:g} d"]
        ax.plot(p[0], p[1], "k^", ms=7)
        ax.annotate(f"fixed {d:g} d", p, textcoords="offset points", xytext=(5, 4), fontsize=8)
    ax.set_xlabel("reviews per concept over 90 days (workload)")
    ax.set_ylabel("mean recall probability at day 90")
    ax.set_title("Workload vs. retention (labels = target recall)")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(RES / "fig3_scheduling_tradeoff.png")
    plt.close(fig)


# ---------------------------------------------------------------- Exp 5
def exp5_retrieval():
    with open(ROOT / "data" / "notes.json", encoding="utf-8") as fh:
        d = json.load(fh)
    docs = [n["title"] + ". " + n["text"] for n in d["notes"]]
    qs = d["queries"]

    def metrics(score_fn):
        top1 = top3 = rr = 0.0
        for q in qs:
            s = score_fn(q["q"])
            order = list(np.argsort(-s, kind="stable"))
            rank = order.index(q["id"]) + 1
            top1 += rank == 1; top3 += rank <= 3; rr += 1.0 / rank
        n = len(qs)
        return top1 / n, top3 / n, rr / n

    idx_stem = TfidfIndex(stem=True).fit(docs)
    idx_raw = TfidfIndex(stem=False).fit(docs)
    res = {"keyword overlap (baseline)": metrics(lambda q: overlap_scores(q, docs)),
           "TF-IDF, no stemming": metrics(idx_raw.scores),
           "TF-IDF + light stemming": metrics(idx_stem.scores)}
    write_csv("exp5_retrieval.csv", ["method", "top1", "top3", "mrr"],
              [(k, *(f"{x:.3f}" for x in v)) for k, v in res.items()])
    # per-query failures of the final method
    fails = []
    for q in qs:
        top = idx_stem.search(q["q"], 1)[0][0]
        if top != q["id"]:
            fails.append({"query": q["q"], "expected": d["notes"][q["id"]]["title"], "got": d["notes"][top]["title"]})
    summary["exp5"] = {"n_notes": len(docs), "n_queries": len(qs), "results": res, "failures": fails,
                       "vocab_size": len(idx_stem.vocab)}
    fig, ax = plt.subplots(figsize=(6.2, 3.8))
    labels = list(res)
    x = np.arange(len(labels)); w = 0.26
    for j, (nm, k) in enumerate((("Top-1", 0), ("Top-3", 1), ("MRR", 2))):
        ax.bar(x + (j - 1) * w, [res[l][k] for l in labels], w, label=nm)
    ax.set_xticks(x); ax.set_xticklabels([l.replace(", ", ",\n").replace(" (", "\n(") for l in labels], fontsize=8)
    ax.set_ylim(0, 1.05); ax.set_ylabel("score")
    ax.set_title(f"Offline retrieval accuracy ({len(qs)} queries, {len(docs)} notes)")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(RES / "fig4_retrieval.png")
    plt.close(fig)

    # latency / footprint (hardware dependent)
    qlist = [q["q"] for q in qs] * 40
    t0 = time.perf_counter()
    for q in qlist:
        idx_stem.search(q, 3)
    ms = (time.perf_counter() - t0) / len(qlist) * 1e3
    summary["latency"] = {"ms_per_query": ms, "index_bytes": int(idx_stem.matrix.nbytes + idx_stem.idf.nbytes),
                          "queries_timed": len(qlist)}


if __name__ == "__main__":
    for fn in (exp1_convergence, exp2_tolerance, exp3_estimation_error, exp4_scheduling, exp5_retrieval):
        t0 = time.perf_counter()
        fn()
        print(f"{fn.__name__:26s} done in {time.perf_counter() - t0:6.1f}s")
    with open(RES / "summary.json", "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2, default=float)
    print("results written to", RES)
