"""Forgetting-curve estimation by maximum likelihood.

Model
-----
The probability that a learner recalls a concept ``t`` days after the last
review is

    p(t) = exp(-lambda * t),        lambda = 1 / S  (S = memory strength, days)

Each review is a Bernoulli outcome y in {0, 1}. To keep lambda positive we
optimise over theta = ln(lambda). With u = t * exp(theta) the per-review
negative log-likelihood is

    l(y=1) = u                      l(y=0) = -ln(1 - exp(-u))

and the *mean* objective over n reviews is minimised by

    * gradient descent with a fixed step size, and
    * a safeguarded Newton method (damped by backtracking).

Derivatives (with f = dl/du):
    f(y=1) = 1,   f(y=0) = -1 / (exp(u) - 1)
    dl/dtheta   = u * f
    d2l/dtheta2 = u * f + u^2 * f'      f'(y=0) = exp(-u) / (1 - exp(-u))^2
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

# theta bounds -> rate in [1e-3, 1e2] per day, i.e. S in [0.01, 1000] days.
THETA_MIN = float(np.log(1e-3))
THETA_MAX = float(np.log(1e2))
THETA_START = float(np.log(0.3))  # initial guess: S ~ 3.3 days


def _u(theta: float, t: np.ndarray) -> np.ndarray:
    return np.clip(t * np.exp(theta), 1e-12, 700.0)


def _f(u: np.ndarray, y: np.ndarray) -> np.ndarray:
    with np.errstate(over="ignore", divide="ignore"):
        return np.where(y == 1, 1.0, -1.0 / np.expm1(u))


def objective(theta: float, t: np.ndarray, y: np.ndarray) -> float:
    """Mean negative log-likelihood."""
    u = _u(theta, t)
    loss = np.where(y == 1, u, -np.log(-np.expm1(-u)))
    return float(np.mean(loss))


def gradient(theta: float, t: np.ndarray, y: np.ndarray) -> float:
    u = _u(theta, t)
    return float(np.mean(u * _f(u, y)))


def hessian(theta: float, t: np.ndarray, y: np.ndarray) -> float:
    u = _u(theta, t)
    fp = np.where(y == 1, 0.0, np.exp(-u) / (-np.expm1(-u)) ** 2)
    return float(np.mean(u * _f(u, y) + u * u * fp))


@dataclass
class FitResult:
    method: str
    theta: float
    iterations: int
    converged: bool
    hit_bound: bool
    objective_history: list = field(default_factory=list)

    @property
    def strength(self) -> float:
        """Estimated memory strength S in days."""
        return float(np.exp(-self.theta))


def _finish(method, theta, k, converged, hist) -> FitResult:
    hit = (not converged) and (theta <= THETA_MIN + 1e-12 or theta >= THETA_MAX - 1e-12)
    return FitResult(method, float(theta), k, converged, hit, hist)


def fit_gradient_descent(t, y, step=0.5, theta0=THETA_START, tol=1e-6, max_iter=5000) -> FitResult:
    """Fixed-step gradient descent. Stops when |gradient| < tol."""
    t = np.asarray(t, float)
    y = np.asarray(y, int)
    theta = float(theta0)
    hist = [objective(theta, t, y)]
    for k in range(max_iter):
        g = gradient(theta, t, y)
        if abs(g) < tol:
            return _finish("gradient_descent", theta, k, True, hist)
        theta = float(np.clip(theta - step * g, THETA_MIN, THETA_MAX))
        hist.append(objective(theta, t, y))
    return _finish("gradient_descent", theta, max_iter, False, hist)


def fit_newton(t, y, theta0=THETA_START, tol=1e-6, max_iter=200) -> FitResult:
    """Newton's method with a gradient fallback (when the Hessian is not
    positive) and step-halving so the objective never increases."""
    t = np.asarray(t, float)
    y = np.asarray(y, int)
    theta = float(theta0)
    hist = [objective(theta, t, y)]
    for k in range(max_iter):
        g = gradient(theta, t, y)
        if abs(g) < tol:
            return _finish("newton", theta, k, True, hist)
        h = hessian(theta, t, y)
        d = -g / h if h > 1e-12 else -g
        alpha, f0, accepted = 1.0, hist[-1], False
        for _ in range(40):
            cand = float(np.clip(theta + alpha * d, THETA_MIN, THETA_MAX))
            fc = objective(cand, t, y)
            if fc <= f0:
                accepted = True
                break
            alpha *= 0.5
        if not accepted or abs(cand - theta) < 1e-15:
            return _finish("newton", theta, k, False, hist)
        theta = cand
        hist.append(fc)
    return _finish("newton", theta, max_iter, False, hist)
