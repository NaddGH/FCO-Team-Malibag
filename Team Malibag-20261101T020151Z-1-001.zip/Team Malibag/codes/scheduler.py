"""Spaced-repetition scheduling from the forgetting curve."""
from __future__ import annotations

import numpy as np

GROW = 1.8     # strength multiplier after a successful review
SHRINK = 0.6   # strength multiplier after a failed review
S_MIN, S_MAX = 0.1, 365.0


def recall_probability(elapsed_days, strength):
    """p = exp(-elapsed / S)."""
    return np.exp(-np.asarray(elapsed_days, float) / np.asarray(strength, float))


def next_interval(strength: float, target: float = 0.85, lo: float = 0.25, hi: float = 60.0) -> float:
    """Days until predicted recall drops to ``target``: t* = -S ln(target)."""
    if not 0.0 < target < 1.0:
        raise ValueError("target must be in (0, 1)")
    return float(np.clip(-strength * np.log(target), lo, hi))


def update_strength(strength: float, success: bool, grow: float = GROW, shrink: float = SHRINK) -> float:
    s = strength * (grow if success else shrink)
    return float(np.clip(s, S_MIN, S_MAX))
