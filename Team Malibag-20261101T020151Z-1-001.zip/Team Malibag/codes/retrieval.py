"""Offline TF-IDF retrieval over local study notes (NumPy only)."""
from __future__ import annotations

import re

import numpy as np

STOPWORDS = frozenset("""a an and are as at be by can do does for from how i if in into is it its of on or
that the their then there these this to was what when where which who why will with you your me my we our
about give tell explain define meaning mean""".split())


def light_stem(w: str) -> str:
    for suf in ("ing", "ed", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[: -len(suf)]
            break
    if w.endswith("e") and len(w) > 4:
        w = w[:-1]
    return w


def tokenize(text: str, stem: bool = True) -> list[str]:
    words = [w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOPWORDS]
    return [light_stem(w) for w in words] if stem else words


class TfidfIndex:
    """idf = ln((1+N)/(1+df)) + 1;  tf = 1 + ln(count);  rows L2-normalised."""

    def __init__(self, stem: bool = True):
        self.stem = stem
        self.vocab: dict[str, int] = {}
        self.idf = np.zeros(0)
        self.matrix = np.zeros((0, 0))

    def fit(self, docs: list[str]) -> "TfidfIndex":
        toks = [tokenize(d, self.stem) for d in docs]
        self.vocab = {w: i for i, w in enumerate(sorted({w for t in toks for w in t}))}
        n, v = len(docs), len(self.vocab)
        counts = np.zeros((n, v))
        for i, t in enumerate(toks):
            for w in t:
                counts[i, self.vocab[w]] += 1
        df = (counts > 0).sum(axis=0)
        self.idf = np.log((1 + n) / (1 + df)) + 1.0
        self.matrix = self._weigh(counts)
        return self

    def _weigh(self, counts: np.ndarray) -> np.ndarray:
        tf = np.where(counts > 0, 1.0 + np.log(np.maximum(counts, 1.0)), 0.0)
        m = tf * self.idf
        norms = np.linalg.norm(m, axis=1, keepdims=True)
        return m / np.where(norms == 0, 1.0, norms)

    def scores(self, query: str) -> np.ndarray:
        counts = np.zeros((1, len(self.vocab)))
        for w in tokenize(query, self.stem):
            if w in self.vocab:
                counts[0, self.vocab[w]] += 1
        return (self._weigh(counts) @ self.matrix.T)[0]

    def search(self, query: str, k: int = 3) -> list[tuple[int, float]]:
        s = self.scores(query)
        order = np.argsort(-s, kind="stable")[:k]
        return [(int(i), float(s[i])) for i in order]


def overlap_scores(query: str, docs: list[str], stem: bool = True) -> np.ndarray:
    """Baseline: fraction of distinct query terms that appear in each note."""
    q = set(tokenize(query, stem))
    if not q:
        return np.zeros(len(docs))
    return np.array([len(q & set(tokenize(d, stem))) / len(q) for d in docs])
